
#ifndef MYTEST_HPP
#define MYTEST_HPP

/* ************************************************************************** */

void SelectOption(unsigned int&);
void SelectDataStructure();
void SelectType(const unsigned int&);
void SelectSize(const unsigned int&, const unsigned int&);
void CreateStructure(const unsigned int&, const unsigned int&, const unsigned int&);

/* ************************************************************************** */

#endif
