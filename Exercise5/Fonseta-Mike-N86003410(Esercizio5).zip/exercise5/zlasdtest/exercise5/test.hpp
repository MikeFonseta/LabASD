
#ifndef EX5TEST_HPP
#define EX5TEST_HPP

/* ************************************************************************** */

void testSimpleExercise5();

void testFullExercise5();

/* ************************************************************************** */

#endif
